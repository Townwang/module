#!/system/bin/sh
MODDIR=${0%/*}
ui_print "[诡域] 模块已完全卸载"
